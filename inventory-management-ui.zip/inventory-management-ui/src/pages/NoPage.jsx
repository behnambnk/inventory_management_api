const NoPage = () => {
    return <h2>Not Found</h2>;
};

export default NoPage;
