import { useState } from 'react';
import { TextInput, PasswordInput, Button, Alert } from '@mantine/core';
import { useForm } from '@mantine/form';
import { useNavigate } from 'react-router-dom';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const Register = () => {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Initialize the form using Mantine's useForm hook
  const form = useForm({
    initialValues: {
      username: '',
      password: '',
      email: ''
    },
    validate: {
      username: (value) => (value.length === 0 ? 'Username is required' : null),
      password: (value) => (value.length < 6 ? 'Password must be at least 6 characters' : null),
      email: (value) => (/^\S+@\S+$/.test(value) ? null : 'Invalid email address'),
    },
  });

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Validate the form before sending the request
    const { username, password, email } = form.values;

    if (form.validate()) {
      console.log('calling api')
      try {
        const response = await fetch(`${API_BASE_URL}/api/auth/signup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password, email }),
        });
       
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.message || 'Registration failed');
        }

        // Redirect to the login page after successful registration
        navigate('/login');
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    } else {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto' }}>
      <h2>Register</h2>
      {error && <Alert color="red">{error}</Alert>}
      <form onSubmit={handleRegister}>
        <TextInput
          label="Username"
          {...form.getInputProps('username')}
          required
          error={form.errors.username}
        />
        <TextInput
          label="Username"
          {...form.getInputProps('email')}
          required
          error={form.errors.email}
        />
        <PasswordInput
          label="Password"
          {...form.getInputProps('password')}
          required
          error={form.errors.password}
        />
        <Button
          type="submit"
          fullWidth
          mt="sm"
          loading={loading}
          disabled={loading}
        >
          Register
        </Button>
      </form>
    </div>
  );
};

export default Register;
