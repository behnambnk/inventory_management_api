import { useState } from 'react'
import '@mantine/core/styles.css';
import { Button } from '@mantine/core';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
        <h2>IFN666 Practical 05</h2>
        <div className="card">
          <Button onClick={() => setCount((count) => count + 1)}>
            Count is {count}
          </Button>
        </div>
    </>
  )
}

export default App
