import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const CreateItem = () => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState(0);
    const [description, setDescription] = useState('');
    const [age, setAge] = useState(0);
    const navigate = useNavigate();
    
    useEffect(() => {
        const jwt = localStorage.getItem('jwt');
        if (!jwt) {
            // Redirect to login page
            window.location.href = '/login';
        }
    }, []);
    
    const handleSubmit = (e) => {
        console.log('submitting')
        e.preventDefault();
        const jwt = localStorage.getItem('jwt');
        const data = {
            name,
            price,
            description,
            age
        };
        fetch(`${API_BASE_URL}/api/items`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt}`
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            console.log(response.ok)
            if (response.ok) {
                console.log('Item created successfully');
                navigate('/items');
            } else {
            }
        })
        .catch(error => {
            // Handle error
        });
    };

    const handleNameChange = (e) => {
        setName(e.target.value);
    };

    const handlePriceChange = (e) => {
        setPrice(Number(e.target.value));
    };

    const handleDescriptionChange = (e) => {
        setDescription(e.target.value);
    };

    const handleAgeChange = (e) => {
        setAge(Number(e.target.value));
    };

    return (
        <div>
            <h1>Create Item</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input type="text" value={name} onChange={handleNameChange} />
                </div>
                <div>
                    <label>Price:</label>
                    <input type="number" value={price} onChange={handlePriceChange} />
                </div>
                <div>
                    <label>Description:</label>
                    <textarea value={description} onChange={handleDescriptionChange} />
                </div>
                <div>
                    <label>Age:</label>
                    <input type="number" value={age} onChange={handleAgeChange} />
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default CreateItem;