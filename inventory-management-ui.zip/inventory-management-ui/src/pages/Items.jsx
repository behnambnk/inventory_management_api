import { useState, useEffect } from 'react';
import { Loader, Alert } from '@mantine/core';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const Items = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchItems = async () => {
      try {
      const token = localStorage.getItem('jwt');
      const response = await fetch(`${API_BASE_URL}/api/items`, {
        headers: {
        Authorization: `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error(`Error: ${response.statusText}`);
      const data = await response.json();
      setItems(data.items); 
      } catch (err) {
      setError(err.message);
      } finally {
      setLoading(false);
      }
    };

    fetchItems();
  }, []);

  if (loading) return <Loader />;
  if (error) return <Alert color="red">{error}</Alert>;

  return (
    <>
      <h2>Items</h2>
      {items.map(item => (
        <div key={item.id}>
          <h3>{item.name}</h3>
          <p>{item.description}</p>
        </div>
      ))}
    </>
  );
};

export default Items;
