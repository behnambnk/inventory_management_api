import { useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Layout from "./pages/Layout";
import Login from './pages/Login';
import Register from './pages/Register';
import Items from './pages/Items';
import CreateItem from './pages/createItem';
import { MantineProvider } from '@mantine/core';
import './App.css';

function App() {
  const [count, setCount] = useState(0)

  return (
    <MantineProvider>
      <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route path="login" element={<Login />} />
              <Route path="register" element={<Register />} />
              <Route path="items" element={<Items />} />
              <Route path="newItem" element={<CreateItem />} />
            </Route>
          </Routes>
        </BrowserRouter>
    </MantineProvider>
  )
}

export default App
